package de.suders.content.layout;

import de.suders.content.logic.Layout;

public class WelcomeLayout extends Layout {

    public WelcomeLayout() {
        super("debugLayout", "debug_table", null);
    }
}
